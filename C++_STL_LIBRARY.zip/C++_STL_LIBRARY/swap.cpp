#include <iostream>
#include <algorithm>
using namespace std;

int main() {
    int a = 1, b = 55;
    cout << a << " " << b << endl;
    
    // swapping the values of a and b
    swap(a, b);
    
    cout << a << " " << b;
    return 0;
}
